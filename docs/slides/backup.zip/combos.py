import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    pos = _kw.get(u'pos')
    _emit(u'<html><body><p>\n\t')
    pos = pos or {}
    _emit(u'\n\t</p><h1>Combo breaker....</h1>\n<p>These combos DO work well together:\n\n\t</p><p><code>def</code> + <code>use</code> + <code>param</code> (with name) + <code>for</code> + <code>if</code>\n</p><p><code>param</code> + <code>set</code> (with name) + <code>for</code> + <code>if</code>\n</p><p><a href="#')
    _emit(_q(_.get(pos, ['next', 'counter'])))
    _emit(u'">On to ')
    _emit(_q((bool(_.get(pos, [u'next', u'value', u'title'])) or "next")))
    _emit(u' &gt;&gt;</a></p>\n\t\n\t')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/combos.tatl')))
    _emit(u'\n</body></html>')
    dot = _.result()
    return dot
# end
