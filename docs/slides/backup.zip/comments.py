import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><h1>Comments and front matter.</h1>\n<p>Comments are NOT processed or sent with the document.\n\n</p><p>Comments with a square bracket as the first character ie, &lt;!--[ --&gt; ARE sent.\nWithout this rule, the "conditional comments" that older versions of IE used would\nnot be sent causing pain.\n\n</p><p>Comments with a brace as the first character are front matter, or metadata about the template.\nYou could store docs, copyright info, etc in here.\n\n</p><p>Front matter must be JSON to ensure maximum interoperability. That means the keys \nmust use quotes unlike maps in this templating language or objects in Javascript.\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/comments.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
