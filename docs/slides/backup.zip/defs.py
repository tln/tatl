import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><h1>Calls, defs</h1>\n<p>This is getting complicated. Lets move out some of the pieces using macros.\nThe second file is called common.html so we can access the macros within using common::name.\n\n</p><p>The <code>def=</code> tag defines a macro. Note that we moved the <code>{labels = {..}}</code> inside the macro.\nWhen it was outside the macro, it was a local var of the implicit html macro. Macros can \nonly access parameters that are passed in.\n\n</p><p>We call a local function via {function()} and function from another template via {template::function()}\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/defs.tatl')))
    _emit(u'\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/defs2.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
