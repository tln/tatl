import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    pos = _kw.get(u'pos')
    _emit('<html><body><p>')
    pos = pos or {}
    _emit(u'\n</p><p>Ok, now lets look at the special *tags*. Just two: <code>&lt;do&gt;</code> acts like any other tag but doesn\'t show up in the output.\n\n</p><p>We\'re using it to loop, where the looped contents don\'t all go in the same tag (it happens).\n\n</p><p><code>&lt;else&gt;</code> works with <code>if=</code>. <code>&lt;else if=""&gt;</code> does what you\'d expect.\n\t\n</p><p>Also, notice we\'re looping over a list of numbers now, and we\'re just writing that list in here directly. \n\t\n</p><p><a href="#')
    _emit(_q(_.get(pos, ['next', 'counter'])))
    _emit('">')
    _emit(_q((bool(_.get(pos, [u'next', u'value', u'title'])) or "next")))
    _emit(u' &gt;&gt;</a>\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/tags.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
