import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    pos = _kw.get(u'pos')
    _emit('<html><body><p>')
    pos = pos or {}
    _emit(u'\n</p><p>From now on we\'ll ignore common. Lets introduce placeholders. We want to put some content at the top to the page (the chide) that we calculate later. Of course, this could be solved in other ways! But it\'s a good introduction point.</p>\n<ul>\n<li> Placeholders make a function. \n</li><li> When called, they put the parameter back where the placeholder was created.\n</li><li> Star placeholders return their argument so they can be inlined\n</li><li> BTW -- there\'s another way to avoid showing an expression result\n</li></ul>\n<p>Lets introduce <a href="#')
    _emit(_q(_.get(pos, ['next', 'counter'])))
    _emit('">')
    _emit(_q((bool(_.get(pos, [u'next', u'value', u'title'])) or "this")))
    _emit(u'</a> next.\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/placeholders.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
