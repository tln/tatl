import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u"<html><body><p>Lets see what happens if the data is more structured. The notices now has a level, text and a link for more details. We just change the substitution to use <code>variable.path</code>.\n\n</p><p>We havent shown what kind of data structure the notices is passed as but dotted paths work with lists, dicts, and objects, and if the key isn't found, its just empty (more on empty).\n\n</p><p>Notice how the empty if came in handy again!\n\n")
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/structured.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
