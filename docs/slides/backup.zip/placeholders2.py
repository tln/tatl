import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><p>Ok. Increment placeholders work somewhat similarly... you can also access the \ncount in further logic.\n\n</p><p>Also: regexes! and ternary operator! The syntax allows regexes, and other comparisons \nin the <code>if=""</code> and with the ternary operator. (and thats all -- this isn\'t as \ngeneral as other languages).\n\n</p><p>We\'re also calling the <code>lede()</code> via <code>use=""</code>. <code>use=""</code> will set <code>.</code> to be the result of the whole tag. Thats what placeholders have as their parameter name by default.\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/placeholders2.tatl')))
    _emit(u'\n</p></body></html>')
    dot = _.result()
    return dot
# end
