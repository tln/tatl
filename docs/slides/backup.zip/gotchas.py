import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><p>It\'s not all unicorns and rainbows! There are some gotchas we should bring up, especially \nabout placeholders.\n\n</p><p>Placeholders don\'t "hold open" your set and will leak outside your if. Compiler should warn about this.\n\n</p><p>Lots of tags together can get pretty confusing. \n\n</p><p>The shortcuts can get out of hand... we\'re showing a few more, for and def.\n\n</p><p>Lets look at how that expands!\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/gotchas.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
