import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><h1>TATL</h1>\n<h2>Tag / Attribute Template Language</h2>\n<h2>A templating system thats good for outputting HTML, for Javascript and Python.</h2>\n<p></p></body></html>')
    dot = _.result()
    return dot
# end
