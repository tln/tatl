import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    pos = _kw.get(u'pos')
    _emit('<html><body><p>')
    pos = pos or {}
    _emit(u'\nPretty basic! <code>{}</code> are *substitions*. <code>for=</code> and <code>if=</code> are special *attributes*. There are a few more\nspecial attributes, which we\'ll see in the advanced section. <a href="#')
    _emit(_q(_.get(pos, ['next', 'counter'])))
    _emit(u'">On to ')
    _emit(_q((bool(_.get(pos, [u'next', u'value', u'title'])) or "next")))
    _emit(u' &gt;&gt;</a>\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/basic.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
