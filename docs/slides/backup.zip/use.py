import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><p>The <code>use=</code> attribute + <code>param=</code> = inheritence.\n\n</p><p>We mentioned the top level tag was implicitly a macro. Specifically, if not other added, a <code>def="html(*)"</code> is assumed.\nThe <code>*</code> means, add any parameters defined to the arguments.\n\n</p><p>We could just call the <code>template::html</code> macro at the end, but a better way is the use="tag".\nThat will find the local variables that correspond to the parameters of the template, \nand pass them.\n\n</p><p>Notice that our parameter isn\'t constrained to being used in a single place. Our base template is using it for the \ntitle of the page, as well. In general you can use variables after they\'re defined, eg you can use variables from a \nfor loop.\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/use.tatl')))
    _emit(u'\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/use2.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
