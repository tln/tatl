import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u"<html><body><h1>More shortcuts! </h1>\n<p>param and set will default to their tag names.\n\n</p><p>param will set '.' to be the value of the parameter.\n\n")
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/moreshortcuts.tatl')))
    _emit(u'\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/moreshortcuts2.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
