import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><h1>More data, more loops.</h1>\n<p>Ok, we need labels for the radio buttons. Lets add set a local variable. Then we look up the number.\nIf its not found, then nothing is inserted -- expression paths don\'t fail on missing values.\n\n</p><p>Lets add another tag: <code>set=""</code>. This will take the tag, after execution of the <code>for</code>, <code>if</code> etc, and\nsave it to a local variable. Theres also a filter -- <code>set=""</code>\n</p><p>For the sake of a scenario, lets say we\'ve decided to nag people about \ntheir number in the footer, too; we\'re referencing our variable like it was passed in.\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/moreloops.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
