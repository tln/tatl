import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    pos = _kw.get(u'pos')
    _emit('<html><body><p>')
    pos = pos or {}
    _emit(u'\n</p><p>We can use shortcuts here. \n\n</p><p>Instead of <code>if="number"</code>, we can just shorten to "<code>if</code>". This basically checks the substitution values. (See elide for all the details)\n\n</p><p>We can also leave the loop variable name off the <code>for=</code> attribute. It will default to <code>.</code> (see the dot).\n\n</p><p>Finally, there\'s syntax to make a list of numbers (more details). \n\n<a href="#')
    _emit(_q(_.get(pos, ['next', 'counter'])))
    _emit('">')
    _emit(_q((bool(_.get(pos, [u'next', u'value', u'title'])) or "next")))
    _emit(u' &gt;&gt;</a>\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/shortcuts.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
