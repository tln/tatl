import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    _emit(u'<html><body><p>Thats it! Dive in further:\n\n</p><ul>\n<li> more data, more loops, set\n\n\t</li><li> calls, defs, modules\n\n\t</li><li> params, inheritence\n\n\t</li><li> magic placeholders\n\n\t</li><li> Gotchas\n\n\t</li><li> Tag combos\n\n\t</li><li> Quoting and context within your HTML doc\n\n\t</li><li> Comments and Front matter\n\n\t</li><li> Tag()\n</li></ul></body></html>')
    dot = _.result()
    return dot
# end
