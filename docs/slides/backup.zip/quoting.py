import tatlrt
def html(**_kw):
    _, _q, _emit = tatlrt._ctx('attr')
    pos = _kw.get(u'pos')
    _emit('<html><body><p>')
    pos = pos or {}
    _emit(u'\n</p><h1>Quoting and content</h1>\n<p>Content is automatically quoted according to position within the document.\n\n</p><p>Doubled braces inserts one brace, and does not start a substitution. A brace just before a tag also inserts \nthe brace without being a substitution.\n\n</p><p>Nothing in the &lt;style&gt; or &lt;script&gt; is substituted.\n\n')
    _emit(_q(_.load(u'builder', [u'as_code'])('slides/quoting.tatl')))
    _emit(u'</p></body></html>')
    dot = _.result()
    return dot
# end
